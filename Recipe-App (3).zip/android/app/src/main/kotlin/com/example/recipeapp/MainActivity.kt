package com.example.recipeapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
